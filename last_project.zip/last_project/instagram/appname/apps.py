from django.apps import AppConfig


class AppnameConfig(AppConfig):
    name = 'appname'
